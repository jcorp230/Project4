﻿/*NameLookup.cs
 * Created By: Juilette Corpstein
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using KansasStateUniversity.TreeViewer2;
using System.IO;

namespace Ksu.Cis300.BTrees
{
    public partial class NameLookup : Form
    {
        public NameLookup()
        {
            InitializeComponent();
        }

       /// <summary>
       /// Stores the tree that is created by reading in a name information.
       /// </summary>
       private Btree<string, NameInformation> _names;


        /// <summary>
        /// Will read in the file that is passed in and will add the contents to a B-Tree.
        /// </summary>
        /// <param name="fn">The file name that you want to read in the data from.</param>
        /// <returns>A B-Tree that contains the string name as a key and information as the value.</returns>
        private Btree<string, NameInformation> ReadFile(string fn)
        {
            int mindeg = Convert.ToInt32(uxMinDegree.Text);
            Btree<string, NameInformation> temp = new Btree<string, NameInformation>(mindeg);

            using (StreamReader sr = new StreamReader(fn))
            {
                while(!sr.EndOfStream)
                {
                    string name = sr.ReadLine().ToString().Trim();
                    float frequency = Convert.ToSingle(sr.ReadLine());
                    int rank = Convert.ToInt32(sr.ReadLine());
                    NameInformation ni = new NameInformation(name, frequency, rank);
                    temp.Insert(name, ni);
                } 
            }
            return temp;
        }

        /// <summary>
        /// Will open a dialog box and handle all of the exceptions.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxOpen_Click(object sender, EventArgs e)
        {
            if (uxOpenDialog.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    string fn = uxOpenDialog.FileName;
                    _names = ReadFile(fn);
                    new TreeForm(_names, 100).Show();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            } 
        }

       /// <summary>
       /// Will lookup the word in the text box and display the corresponding information.
       /// </summary>
       /// <param name="sender"></param>
       /// <param name="e"></param>
       private void uxLookup_Click(object sender, EventArgs e)
        {
            try
            {
                string name = uxName.Text.Trim().ToUpper();
                NameInformation info = _names.Find(name);


                if (info.Name != null)
                {
                    uxFrequency.Text = Convert.ToString(info.Frequency);
                    uxRank.Text = Convert.ToString(info.Rank);
                }
                else
                {
                    uxFrequency.Text = "";
                    uxRank.Text = "";
                    MessageBox.Show("Name was not found.");
                }
             }catch(Exception ex)
            {
                uxFrequency.Text = "";
                uxRank.Text = "";
                MessageBox.Show("Name was not found.");
            }
    }

        /// <summary>
        /// Will make a B-Tree to test functinality.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void uxMakeTree_Click(object sender, EventArgs e)
        {
            Btree<int, int> tree = new Btree<int, int>((int)uxMinDegree.Value);

            for(int i = 1; i <= Convert.ToInt32( uxCount.Value); i++ )
            {
                tree.Insert(i, i);
            }
            new TreeForm(tree, 100).Show(); 
        }

   
    }
}
