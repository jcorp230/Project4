﻿/*Btree.cs
 * Created By: Juliette Corpstein
 */

using KansasStateUniversity.TreeViewer2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ksu.Cis300.BTrees
{
    public class Btree<TKey, TValue> : ITree where TKey : IComparable<TKey>
    {

        /// <summary>
        /// The minimum degree of the tree, minimun number of children for nodes in the tree.
        /// </summary>
        private int _size;

        /// <summary>
        /// The mamimum number of children for teh node in the tree (size * 2).
        /// </summary>
        private int _maxChildren;

       /// <summary>
       /// Minimum number of the keys for each node in the tree (_size -1).
       /// </summary>
       private int _minKeys;

        /// <summary>
        /// Mamimum number of keys for each node in the tree  (_size * 2 -1).
        /// </summary>
        private int _maxkeys;

        /// <summary>
        /// The root node of the tree.
        /// </summary>
        private BtreeNode<TKey, TValue> _root;

        /// <summary>
        /// Public property that gets the root of the node.
        /// </summary>
        public object Root
        {
            get
            {
                return _root;
            }
        }

        /// <summary>
        /// Will get the children of the root node.
        /// </summary>
        public ITree[] Children
        {
            get
            {
               return (ITree[])_root.Children;
            }
        }

        /// <summary>
        /// Will get if the root is empty or not.
        /// </summary>
        public bool IsEmpty
        {
            get
            {
                return _root == null;
            }
        }

       /// <summary>
       /// Initalizer that will set all values.
       /// </summary>
       /// <param name="size">The size that you set all the values by</param>
       public Btree(int size)
        {
            if (size < 2)
                throw new InvalidOperationException();
            _size = size;
            _maxChildren = size * 2;
            _minKeys = size -1;
            _maxkeys = size * 2 -1;
            _root = new BtreeNode<TKey, TValue>(_minKeys, _maxkeys, _maxChildren, true);
        }


        /// <summary>
        /// Will insert the given key and value to the root or create a new one if needed.
        /// </summary>
        /// <param name="key">The key to add</param>
        /// <param name="value">The value to add</param>
        public void Insert(TKey key, TValue value)
        {
            if (_root.IsEmpty)
            {
                _root.AddItem(key, value);
            }
            else
            {
                if (_root.KeyCount != _maxkeys)
                {
                    _root.InsertNonFull(key, value);
                }
                else
                {
                    BtreeNode<TKey, TValue> temp = new BtreeNode<TKey, TValue>(_minKeys, _maxkeys, _maxChildren, false);

                    temp.AddChild(0, _root);
                    temp.SplitChild(0);
                    temp.InsertNonFull(key, value);
                    _root = temp;
                }
            }
        }


        /// <summary>
        /// Will find the given key and return the data that corresponds to the key.
        /// </summary>
        /// <param name="key">The key of the items we want to find.</param>
        /// <returns>The value that corresponds to the key.</returns>
        public TValue Find(TKey key)
        {
            return _root.Find(key);
        }


    }//end class
}
