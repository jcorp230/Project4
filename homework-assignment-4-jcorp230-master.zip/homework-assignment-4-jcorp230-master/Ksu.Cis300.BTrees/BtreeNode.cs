﻿/* BtreeNode.cs
 * Created By: Juliette Corpstein
 */

using KansasStateUniversity.TreeViewer2;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ksu.Cis300.BTrees
{
    class BtreeNode<TKey, TValue> : ITree where TKey : IComparable<TKey>
    {
        
        /// <summary>
        /// Keeps track of how many keys are curnenty in this node.
        /// </summary>
        private int _keyCount;

        /// <summary>
        /// Stores the minimum number of keys this node can have.
        /// </summary>
        private int _minKeyCount;

       
        /// <summary>
        /// An array that holds the keys of ths node in ascending order.
        /// </summary>
        private TKey[] _keys;

        /// <summary>
        /// Keeps track of the number of children in this node.
        /// </summary>
        private int _childCount;

         /// <summary>
        /// Stores the values of the corresponding keys from the keys array.
        /// </summary>
        private TValue[] _values;

        /// <summary>
        /// Indicates if this node is a leaf or not.
        /// </summary>
        private bool _isLeaf;

        /// <summary>
        /// An array that stores the pointers to the children of this node.
        /// </summary>
        private BtreeNode<TKey, TValue>[] _children;


        /// <summary>
        /// Will return that node.
        /// </summary>
        public object Root
        {
            get
            {
                return this;
            }
        }

        /// <summary>
        /// Property to access the array that stores that pointers to the children of the node.
        /// </summary>
        public ITree[] Children
        {
            get
            {
                return _children;
            }
        }

        /// <summary>
        /// Public property that returns a value if there are keys in the node.
        /// </summary>
        public bool IsEmpty
        {
            get
            {
                return _keyCount == 0;
            }
        }

        /// <summary>
        /// Public property to access how many keys are in the node.
        /// </summary>
        public int KeyCount
        {
            get
            {
                return _keyCount;
            }
        }

        /// <summary>
        /// Public property to access if the node contains a leaf.
        /// </summary>
        public bool IsLeaf
        {
            get
            {
                return _isLeaf;
            }
        }
    

       /// <summary>
       /// Constructor for a new B tree node.
       /// </summary>
       /// <param name="minKeyCount">The minimun number of keys in the node</param>
       /// <param name="maxKeyCount">how many keys are curently stored in the node</param>
       /// <param name="maxChildCount">how many children are in the node</param>
       /// <param name="leaf">if this node is a leaf or has other children</param>
       public BtreeNode(int minKeyCount, int maxKeyCount, int maxChildCount, bool leaf)
        {
            _keys = new TKey[maxKeyCount];
            _values = new TValue[maxKeyCount];
            _minKeyCount = minKeyCount;
            _isLeaf = leaf;
            _children = new BtreeNode<TKey, TValue>[maxChildCount];
        }


        /// <summary>
        /// Will add the key and value to there respective arrays in asscending order.
        /// </summary>
        /// <param name="key">The key that you want to add.</param>
        /// <param name="value">The value you want to add at the same location.</param>
        public void AddItem(TKey key, TValue value)
        {
            for (int i = _keyCount - 1; i >= 0; i--)
            {
                int comp = key.CompareTo(_keys[i]);
                if (comp <= 0)
                {
                    _keys[i + 1] = _keys[i];
                    _values[i + 1] = _values[i];
                }
                else
                {
                    _keys[i + 1] = key;
                    _values[i + 1] = value;
                    _keyCount++;
                    return;
                }
            }
            _keys[0] = key;
            _values[0] = value;
            _keyCount++;
        }
            
         
        /// <summary>
        /// Will add the child at the location given.
        /// </summary>
        /// <param name="i">The index you want to add the child to.</param>
        /// <param name="child">The child you want to add.</param>
        public void AddChild(int i, BtreeNode<TKey, TValue> child)
        {
            _children[i] = child;
            _childCount++;
        }


        /// <summary>
        /// Will split the children in to a new node if they fill up.
        /// </summary>
        /// <param name="index">Indicates what child to split</param>
        public void SplitChild(int index)
        {
            BtreeNode<TKey, TValue> split = _children[index];
            BtreeNode<TKey, TValue> temp = new BtreeNode<TKey, TValue>(_minKeyCount, _keys.Length, _children.Length, split.IsLeaf);
            
            for (int i = 0, k = i + _minKeyCount + 1; i < _minKeyCount; i++, k++)
            {

                temp.AddItem(split._keys[k], split._values[k]);
                split._keys[k] = default(TKey);
                split._values[k] = default(TValue);
            }

            if (!temp.IsLeaf)
            {
                for (int i = _children.Length / 2, j = 0; i < _children.Length; i++, j++)
                {
                    if (split._children[i] != null)
                    {
                        temp.AddChild(j, split._children[i]);
                        split._children[i] = null;
                        split._childCount--;
                    }
                }
            }

            split._keyCount = _minKeyCount;

            for (int i = _keyCount; i >= index + 1; i--)
            {
                _children[i + 1] = _children[1];
            }
            _children[index + 1] = temp;

            AddItem(split._keys[_minKeyCount], split._values[_minKeyCount]);
            split._keys[_minKeyCount] = default(TKey);
            split._values[_minKeyCount] = default(TValue);
        }


        /// <summary>
        /// Inserts into a tree whose root is not already full.
        /// </summary>
        /// <param name="key">Key you want to insert</param>
        /// <param name="value">The value you want to insert</param>
        public void InsertNonFull(TKey key, TValue value)
        {
            if (_isLeaf)
            {
                AddItem(key, value);
            }
            else
            {
                int k = _keyCount - 1;
                while (k >= 0 && _keys[k].CompareTo(key) > 0)
                {
                    k--;
                }
                k++;

                if (_children[k]._keyCount == _keys.Length)
                {
                    SplitChild(k);

                    int compare = _keys[k].CompareTo(key);
                    if (compare < 0)
                    {
                        k++;
                    }
                }
                _children[k].InsertNonFull(key, value);
            }
        }



        /// <summary>
        /// Will find the key and return the value that is stored at the same location.
        /// </summary>
        /// <param name="key">The key you want to find</param>
        /// <returns>The value that corresponds to the key</returns>
        public TValue Find(TKey key)
        {
            int index = Array.IndexOf(_keys, key);

            if (index > -1)
            {
                return _values[index];
            }
            if (_isLeaf)
            {
                return default(TValue);
            }
            int i = 0;
            while (i < _keyCount && _keys[i].CompareTo(key) < 0)
            {
                i++;
            }
            return _children[i].Find(key);
        }

        /// <summary>
        /// Will print out a string of the keys seperated wiht a |.
        /// </summary>
        /// <returns>A string of the keys styalized with |</returns>
        override public string ToString()
        {
            return String.Join(" | ", _keys.Where(s => s!=null ? s.CompareTo(default(TKey)) != 0 : false));
        }


    }//end class
}
